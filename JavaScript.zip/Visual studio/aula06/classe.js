class Ponto {
    constructor(x, w){
        this.w = w;
        this.x = x;
    }

    toString(){
        return '[X= ' + this.x + ', w=' + this.w + ']';
    }
}

class PintarPonto extends Ponto {
    static default(){
        return new PintarPonto(0,0 , "azul");
    }

    constructor(w,x, cor){
        super(w,x)
        this.cor = cor
    }

    toString(){
        return '[ X=' +this.x + ', W=' +this.w+ ', cor='+ this.cor +']'
    }
}

var chico = new Ponto(4,5);
console.log('>>>>>>>>>>>>> ' + new Ponto(4,5))
console.log('>>>>>>>>>>>>> ' + new PintarPonto(13,12,'Azul'))
console.log('>>>>>>>>>>>>> ' + chico)