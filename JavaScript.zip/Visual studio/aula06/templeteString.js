const nomeCompleto = (nome,sobrenome) => {
    return `O nome é ${nome} ${sobrenome}`
}

console.log(nomeCompleto('Evandro','Firmino'))