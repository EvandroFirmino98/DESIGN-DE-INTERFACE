const cor = 'branco'

const ponto = {
    x: 3,
    y: 10,
    cor,
    toString(){
        return '[X= ' + this.x + ', w=' + this.y + ']';
    },

    ['carlos_', + 10]: 20
}

console.log('>>>>>>>>>>>>> ' + ponto.toString)