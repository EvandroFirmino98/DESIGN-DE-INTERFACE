var numeros = [2,3,5,12,31,4]

const soma = (ac, valor) =>{
    const resultado = ac + valor;
    console.log(resultado);
    return resultado;
}

const sub = (ac, valor) =>{
    const resultado = ac - valor;
    console.log(resultado);
    return resultado;
}

const divi = (ac, valor) =>{
    const resultado = ac / valor;
    console.log(resultado);
    return resultado;
}

const multi = (ac, valor) =>{
    const resultado = ac * valor;
    console.log(resultado);
    return resultado;
}

var somarDeTodosOsElementos = numeros.reduce(soma, 1);
console.log(multDeTodosOsElementos);
