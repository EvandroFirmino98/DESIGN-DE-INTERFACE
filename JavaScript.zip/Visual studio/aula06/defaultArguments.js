const empregados = (prof=[], cpf = '031.415.123-55') => {
    console.log(prof, cpf)
}

empregados(['analista, programador, testado'], '4894848455456456')