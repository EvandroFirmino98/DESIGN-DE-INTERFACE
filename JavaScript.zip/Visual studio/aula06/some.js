var empregado = [
    {nome:'Carlos filho', idade: 24},
    {nome:'Valdir', idade: 22},
    {nome:'Barbara', idade: 21},
    {nome:'Suzana', idade: 34}
]

// True ou False
function verificaIdade(empregado){
    return empregado.idade >20 && empregado.idade <30;
}

let vericaEmpregado = empregado.some(verificaIdade)
console.log(vericaEmpregado);