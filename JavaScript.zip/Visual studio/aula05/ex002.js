var carros = ['fusca', 'uno', 'combi', 'chevete'];

function imprimeCarros(dado){
    console.log(dado);
}

function upperCase(dado){
    return dado.toUpperCase()
}

let imprimeCarros = carros.map(upperCase)

console.log(carrosUperCase);

var numeros = [1,34,54,23,12,21,7,6,78]

function numerosMenores(dado){
    return dado < 30
}

let menoresQue30 = numeros.filter(numerosMenores)
console.log(menoresQue30)