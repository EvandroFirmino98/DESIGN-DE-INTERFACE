var funcionarios = [
    {nome: 'Evandro', idade: '43'},
    {nome: 'Debora', idade: '53'},
    {nome: 'Amanda', idade: '18'},
    {nome: 'Diego', idade: '23'},
    {nome: 'Manoel', idade: '24'}
];

function recuperaFuncionario(dado){
    return dado.idade > 20 && dado.idade < 50;
}

var primeiroFuncionario = funcionarios.every(recuperaFuncionario)
console.log(">>>>>>>>>>> o funcionario é " + primeiroFuncionario);