function xpto(){
    var x = 1;
    let y = 2;
    const w = 3;

    console.log("x "+ x);
    console.log("y "+ y);
    console.log("w "+ w);
}
{
    var x = 10;
    let y = 20;
    const w = 30;

    console.log("x "+ x);
    console.log("y "+ y);
    console.log("w "+ w);
}

xpto();