document.getElementById("ligar").innerHTML = "ligar"
document.getElementById("desligar").innerHTML = "desligar"

function ligar(){
    document.getElementById('lampada').src='imagens/on.gif'
}
function desligar(){
    document.getElementById('lampada').src='imagens/off.gif'
}