if(a % b) {
    console.log("A é divisível por B");
} else {
    console.log("A não é divisível por B");
}